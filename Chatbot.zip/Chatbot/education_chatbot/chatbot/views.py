from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
import openai
from django.conf import settings

# Home view to display a welcome message
def home(request):
    return HttpResponse("Welcome to the Educational Chatbot!")

def chatbot_response(request):
    user_message = request.GET.get('message', 'Hello')
    response = f"You said: {user_message}"
    return JsonResponse({"response": response})

# Set the OpenAI API key from Django settings
import openai
from django.http import JsonResponse

openai.api_key = "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"  # Replace with your actual OpenAI API key

def chatbot_response(request):
    user_message = request.GET.get('message', '')
    response = "I'm here to help, but I didn't understand that."

    if user_message:
        try:
            openai_response = openai.ChatCompletion.create(
                model="gpt-4o",
                messages=[
                    {"role": "user", "content": user_message}
                ]
            )
            response = openai_response['choices'][0]['message']['content'].strip()
        except Exception as e:
            response = f"Error: {str(e)}"  # Handle potential API errors

    return JsonResponse({"response": response})

def chat_page(request):
    return render(request, 'chat.html')
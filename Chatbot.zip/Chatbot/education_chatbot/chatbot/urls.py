from django.urls import path
from . import views

urlpatterns = [
    path('', views.chat_page, name='chat_page'),  # The main chat page
    path('chatbot/get-response/', views.chatbot_response, name='chatbot_response'),  # Chatbot response endpoint
]